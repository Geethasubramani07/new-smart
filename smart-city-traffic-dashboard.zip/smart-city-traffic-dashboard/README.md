# Smart City Traffic Dashboard

Real-time traffic dashboard with a live city map, KPIs, congestion trend,
per-junction bar chart, incident feed and junction table.
Data is simulated (rush-hour peaks at ~9:30 and ~18:30 IST), refreshed every 2 seconds.

**Stack:** Node.js (built-ins only, no npm packages) + vanilla HTML/CSS/JS.

## Run in VS Code

1. Install Node.js 18+ from https://nodejs.org
2. Unzip the project, then in VS Code: **File > Open Folder** and pick `smart-city-traffic-dashboard`
3. Open the terminal (**Ctrl + `**) and run:

   ```bash
   npm start
   ```

4. Open http://localhost:3000

## Deploy on Render

1. Push this folder to a GitHub repository (the `.zip` contents go at the repo root, `package.json` must be at the top level).
2. On https://render.com: **New > Web Service** and connect the repo.
3. Use these settings:
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. Click **Create Web Service**. When the deploy is live, open the `.onrender.com` URL and the dashboard loads.

(Or choose **New > Blueprint**, which reads `render.yaml` automatically.)

> Free instances sleep after inactivity, so the first load can take ~30-50 seconds.

## Project structure

```
server.js          backend: simulation + JSON API + static file server
public/index.html  dashboard page
public/style.css   styles
public/app.js      map, charts, polling logic
render.yaml        Render blueprint
```

## API

| Route          | Description                              |
|----------------|------------------------------------------|
| `/api/traffic` | Live snapshot (KPIs, junctions, incidents) |
| `/api/history` | City congestion history                  |
| `/health`      | Health check                             |
