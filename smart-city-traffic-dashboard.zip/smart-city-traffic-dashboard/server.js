/**
 * Smart City Traffic Dashboard - backend
 * Zero dependencies: only Node.js built-ins. Works locally and on Render.
 *
 * Endpoints
 *   GET /api/traffic    -> live snapshot of every junction + KPIs + incidents
 *   GET /api/history    -> rolling history of city-wide congestion
 *   GET /health         -> health check (used by Render)
 *   GET /*              -> static files from ./public
 */
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const HOST = "0.0.0.0"; // required on Render
const PUBLIC_DIR = path.join(__dirname, "public");

/* ------------------------------------------------------------------ */
/* Simulated city data                                                 */
/* ------------------------------------------------------------------ */
const JUNCTIONS = [
  { id: "J1", name: "Silk Board",        x: 52, y: 78, base: 0.85, lanes: 6 },
  { id: "J2", name: "Hebbal Flyover",    x: 46, y: 12, base: 0.78, lanes: 6 },
  { id: "J3", name: "KR Puram",          x: 78, y: 40, base: 0.74, lanes: 4 },
  { id: "J4", name: "Marathahalli",      x: 80, y: 58, base: 0.72, lanes: 4 },
  { id: "J5", name: "MG Road",           x: 52, y: 44, base: 0.62, lanes: 4 },
  { id: "J6", name: "Majestic",          x: 36, y: 42, base: 0.68, lanes: 4 },
  { id: "J7", name: "Electronic City",   x: 66, y: 92, base: 0.66, lanes: 6 },
  { id: "J8", name: "Whitefield",        x: 92, y: 48, base: 0.58, lanes: 4 },
  { id: "J9", name: "Jayanagar 4th Blk", x: 40, y: 68, base: 0.50, lanes: 2 },
  { id: "J10", name: "Yeshwanthpur",     x: 22, y: 26, base: 0.60, lanes: 4 },
];

// Roads connecting junctions (for the map)
const ROADS = [
  ["J2", "J5"], ["J2", "J10"], ["J10", "J6"], ["J6", "J5"], ["J5", "J3"],
  ["J3", "J8"], ["J3", "J4"], ["J4", "J8"], ["J5", "J9"], ["J9", "J1"],
  ["J6", "J9"], ["J1", "J7"], ["J4", "J1"], ["J5", "J4"],
];

const INCIDENT_TYPES = [
  "Vehicle breakdown", "Minor collision", "Waterlogging", "Signal malfunction",
  "Road work", "VIP movement", "Stalled bus", "Procession / event",
];

/* ------------------------------------------------------------------ */
/* Simulation helpers                                                  */
/* ------------------------------------------------------------------ */
function rand(min, max) { return Math.random() * (max - min) + min; }
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

// Time-of-day demand curve (IST). Peaks at ~9:30 and ~18:30.
function demandFactor(date = new Date()) {
  const ist = new Date(date.getTime() + (5.5 * 60 + date.getTimezoneOffset()) * 60000);
  const h = ist.getHours() + ist.getMinutes() / 60;
  const gauss = (x, mu, sigma) => Math.exp(-Math.pow(x - mu, 2) / (2 * sigma * sigma));
  const f = 0.25 + 0.75 * Math.max(gauss(h, 9.5, 1.6), gauss(h, 18.5, 1.9), 0.45 * gauss(h, 13, 2));
  return clamp(f, 0.2, 1);
}

function levelFor(c) {
  if (c < 0.35) return "free";
  if (c < 0.6) return "moderate";
  if (c < 0.8) return "heavy";
  return "severe";
}

const state = {
  junctions: JUNCTIONS.map((j) => ({
    ...j,
    congestion: clamp(j.base * 0.6, 0.1, 1),
    avgSpeed: 30,
    vehicles: 0,
    signalPhase: Math.random() > 0.5 ? "green" : "red",
    signalTimer: Math.floor(rand(5, 40)),
  })),
  incidents: [],
  history: [],
  nextIncidentId: 1,
  tick: 0,
};

function spawnIncident() {
  const j = state.junctions[Math.floor(Math.random() * state.junctions.length)];
  const severity = ["low", "medium", "high"][Math.floor(Math.random() * 3)];
  state.incidents.unshift({
    id: state.nextIncidentId++,
    junctionId: j.id,
    junction: j.name,
    type: INCIDENT_TYPES[Math.floor(Math.random() * INCIDENT_TYPES.length)],
    severity,
    startedAt: Date.now(),
    expiresAt: Date.now() + rand(40, 150) * 1000,
  });
  state.incidents = state.incidents.slice(0, 12);
}

function step() {
  state.tick++;
  const demand = demandFactor();
  const now = Date.now();

  // expire incidents
  state.incidents = state.incidents.filter((i) => i.expiresAt > now);
  if (Math.random() < 0.12 && state.incidents.length < 6) spawnIncident();

  const incidentBoost = {};
  state.incidents.forEach((i) => {
    incidentBoost[i.junctionId] =
      (incidentBoost[i.junctionId] || 0) + { low: 0.06, medium: 0.12, high: 0.2 }[i.severity];
  });

  state.junctions.forEach((j) => {
    const target = clamp(j.base * demand + (incidentBoost[j.id] || 0) + rand(-0.04, 0.04), 0.05, 1);
    // smooth towards target
    j.congestion = clamp(j.congestion + (target - j.congestion) * 0.35 + rand(-0.015, 0.015), 0.03, 1);
    j.avgSpeed = Math.round(clamp(55 * (1 - j.congestion * 0.88) + rand(-2, 2), 4, 60));
    j.vehicles = Math.round(j.lanes * (30 + 160 * j.congestion) + rand(-8, 8));

    j.signalTimer -= 1;
    if (j.signalTimer <= 0) {
      j.signalPhase = j.signalPhase === "green" ? "red" : "green";
      j.signalTimer = Math.round(25 + j.congestion * 40);
    }
  });

  const avg = state.junctions.reduce((s, j) => s + j.congestion, 0) / state.junctions.length;
  state.history.push({ t: now, congestion: +avg.toFixed(3) });
  if (state.history.length > 120) state.history.shift();
}

// seed ~60 points of history so charts aren't empty on first load
for (let i = 0; i < 60; i++) step();
setInterval(step, 2000);

/* ------------------------------------------------------------------ */
/* Snapshot builder                                                    */
/* ------------------------------------------------------------------ */
function snapshot() {
  const js = state.junctions.map((j) => ({
    id: j.id, name: j.name, x: j.x, y: j.y,
    congestion: +j.congestion.toFixed(3),
    level: levelFor(j.congestion),
    avgSpeed: j.avgSpeed,
    vehicles: j.vehicles,
    signalPhase: j.signalPhase,
    signalTimer: j.signalTimer,
  }));
  const total = js.reduce((s, j) => s + j.vehicles, 0);
  const avgCong = js.reduce((s, j) => s + j.congestion, 0) / js.length;
  const avgSpeed = js.reduce((s, j) => s + j.avgSpeed, 0) / js.length;
  const worst = [...js].sort((a, b) => b.congestion - a.congestion)[0];

  return {
    timestamp: Date.now(),
    demand: +demandFactor().toFixed(2),
    kpis: {
      avgCongestion: Math.round(avgCong * 100),
      avgSpeed: Math.round(avgSpeed),
      totalVehicles: total,
      activeIncidents: state.incidents.length,
      worstJunction: worst.name,
      worstCongestion: Math.round(worst.congestion * 100),
      co2KgPerHour: Math.round(total * 0.11 * (0.6 + avgCong)), // rough indicative figure
    },
    junctions: js,
    roads: ROADS,
    incidents: state.incidents.map((i) => ({
      id: i.id, junction: i.junction, type: i.type, severity: i.severity,
      ageSec: Math.round((Date.now() - i.startedAt) / 1000),
    })),
  };
}

/* ------------------------------------------------------------------ */
/* HTTP server                                                         */
/* ------------------------------------------------------------------ */
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

function sendJSON(res, obj, status = 200) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*",
  });
  res.end(JSON.stringify(obj));
}

const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent((req.url || "/").split("?")[0]);

  if (urlPath === "/health") return sendJSON(res, { status: "ok", uptime: process.uptime() });
  if (urlPath === "/api/traffic") return sendJSON(res, snapshot());
  if (urlPath === "/api/history") return sendJSON(res, state.history);

  // static files (with path traversal protection)
  let rel = urlPath === "/" ? "/index.html" : urlPath;
  const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); return res.end("Forbidden");
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain" });
      return res.end("Not found");
    }
    res.writeHead(200, {
      "Content-Type": MIME[path.extname(filePath)] || "application/octet-stream",
    });
    res.end(data);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`Smart City Traffic Dashboard running on http://localhost:${PORT}`);
});
