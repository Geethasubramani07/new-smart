/* Smart City Traffic Dashboard - frontend (vanilla JS, no build step) */
const COLORS = {
  free: "#2ecc71", moderate: "#f4d03f", heavy: "#ff9f43", severe: "#ff4d5e",
  accent: "#4da3ff", grid: "#25324d", text: "#8a97b3",
};
const $ = (id) => document.getElementById(id);
const REFRESH_MS = 2000;

function levelFor(c) {
  if (c < 0.35) return "free";
  if (c < 0.6) return "moderate";
  if (c < 0.8) return "heavy";
  return "severe";
}
const LEVEL_LABEL = { free: "Free flow", moderate: "Moderate", heavy: "Heavy", severe: "Severe" };

/* ---------------- Clock ---------------- */
setInterval(() => {
  $("clock").textContent = new Date().toLocaleTimeString("en-IN", { hour12: false });
}, 1000);

/* ---------------- Map ---------------- */
const SVGNS = "http://www.w3.org/2000/svg";
function el(name, attrs = {}, text) {
  const n = document.createElementNS(SVGNS, name);
  for (const k in attrs) n.setAttribute(k, attrs[k]);
  if (text !== undefined) n.textContent = text;
  return n;
}

function drawMap(data) {
  const svg = $("map");
  svg.innerHTML = "";
  const byId = Object.fromEntries(data.junctions.map((j) => [j.id, j]));

  // roads
  data.roads.forEach(([a, b]) => {
    const ja = byId[a], jb = byId[b];
    if (!ja || !jb) return;
    const worst = Math.max(ja.congestion, jb.congestion);
    svg.appendChild(el("line", {
      x1: ja.x, y1: ja.y, x2: jb.x, y2: jb.y,
      stroke: COLORS[levelFor(worst)], "stroke-width": 0.9, "stroke-linecap": "round", opacity: 0.55,
    }));
  });

  // junction nodes
  data.junctions.forEach((j) => {
    const c = COLORS[j.level];
    const r = 2.2 + j.congestion * 2.2;
    if (j.level === "severe") {
      const halo = el("circle", { cx: j.x, cy: j.y, r: r + 1.5, fill: c, opacity: 0.25 });
      halo.appendChild(el("animate", { attributeName: "r", values: `${r};${r + 3};${r}`, dur: "1.6s", repeatCount: "indefinite" }));
      svg.appendChild(halo);
    }
    const g = el("g");
    g.appendChild(el("circle", { cx: j.x, cy: j.y, r, fill: c, stroke: "#0b1220", "stroke-width": 0.5 }));
    g.appendChild(el("title", {}, `${j.name}: ${Math.round(j.congestion * 100)}% congestion, ${j.avgSpeed} km/h`));
    svg.appendChild(g);
    svg.appendChild(el("text", {
      x: j.x, y: j.y - r - 1.4, "text-anchor": "middle", fill: "#e6ecf7",
      "font-size": 2.8, "font-weight": 600,
    }, j.name));
  });
}

/* ---------------- Charts (canvas, no libraries) ---------------- */
function setupCanvas(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth;
  const h = parseInt(canvas.getAttribute("height"), 10);
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  return { ctx, w, h };
}

function drawTrend(history) {
  const { ctx, w, h } = setupCanvas($("trend"));
  const pad = { l: 36, r: 12, t: 10, b: 22 };
  const pw = w - pad.l - pad.r, ph = h - pad.t - pad.b;
  ctx.font = "11px system-ui"; ctx.fillStyle = COLORS.text; ctx.strokeStyle = COLORS.grid;

  // grid + y labels
  for (let v = 0; v <= 100; v += 25) {
    const y = pad.t + ph - (v / 100) * ph;
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
    ctx.textAlign = "right"; ctx.fillText(v + "%", pad.l - 6, y + 4);
  }
  if (history.length < 2) return;

  const pts = history.map((p, i) => ({
    x: pad.l + (i / (history.length - 1)) * pw,
    y: pad.t + ph - p.congestion * ph,
  }));

  // area
  const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + ph);
  grad.addColorStop(0, "rgba(77,163,255,.35)"); grad.addColorStop(1, "rgba(77,163,255,0)");
  ctx.beginPath(); ctx.moveTo(pts[0].x, pad.t + ph);
  pts.forEach((p) => ctx.lineTo(p.x, p.y));
  ctx.lineTo(pts[pts.length - 1].x, pad.t + ph); ctx.closePath();
  ctx.fillStyle = grad; ctx.fill();

  // line
  ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.strokeStyle = COLORS.accent; ctx.lineWidth = 2; ctx.stroke(); ctx.lineWidth = 1;

  // x labels: first / last time
  ctx.fillStyle = COLORS.text; ctx.textAlign = "left";
  ctx.fillText(new Date(history[0].t).toLocaleTimeString("en-IN", { hour12: false }), pad.l, h - 6);
  ctx.textAlign = "right";
  ctx.fillText(new Date(history[history.length - 1].t).toLocaleTimeString("en-IN", { hour12: false }), w - pad.r, h - 6);
}

function drawBars(junctions) {
  const { ctx, w, h } = setupCanvas($("bars"));
  const sorted = [...junctions].sort((a, b) => b.congestion - a.congestion);
  const pad = { l: 8, r: 8, t: 8, b: 44 };
  const pw = w - pad.l - pad.r, ph = h - pad.t - pad.b;
  const bw = pw / sorted.length;

  ctx.strokeStyle = COLORS.grid;
  [0, 50, 100].forEach((v) => {
    const y = pad.t + ph - (v / 100) * ph;
    ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
  });

  sorted.forEach((j, i) => {
    const bh = j.congestion * ph;
    const x = pad.l + i * bw + bw * 0.18;
    const y = pad.t + ph - bh;
    ctx.fillStyle = COLORS[j.level];
    ctx.fillRect(x, y, bw * 0.64, bh);

    ctx.fillStyle = "#e6ecf7"; ctx.font = "600 10px system-ui"; ctx.textAlign = "center";
    ctx.fillText(Math.round(j.congestion * 100), x + bw * 0.32, y - 3);

    ctx.save();
    ctx.translate(x + bw * 0.32, pad.t + ph + 8);
    ctx.rotate(Math.PI / 4);
    ctx.fillStyle = COLORS.text; ctx.font = "10px system-ui"; ctx.textAlign = "left";
    ctx.fillText(j.name.length > 12 ? j.name.slice(0, 11) + "…" : j.name, 0, 0);
    ctx.restore();
  });
}

/* ---------------- Panels ---------------- */
function renderKpis(k) {
  $("kCong").textContent = k.avgCongestion + "%";
  $("kCong").style.color = COLORS[levelFor(k.avgCongestion / 100)];
  $("kCongLvl").textContent = LEVEL_LABEL[levelFor(k.avgCongestion / 100)];
  $("kSpeed").textContent = k.avgSpeed;
  $("kVeh").textContent = k.totalVehicles.toLocaleString("en-IN");
  $("kInc").textContent = k.activeIncidents;
  $("kWorst").textContent = `Worst: ${k.worstJunction} (${k.worstCongestion}%)`;
  $("kCo2").textContent = k.co2KgPerHour.toLocaleString("en-IN");
}

function renderIncidents(list) {
  const ul = $("incidents");
  $("incCount").textContent = list.length ? `${list.length} active` : "";
  if (!list.length) { ul.innerHTML = '<li class="empty" style="border:none;background:none">No active incidents &#10003;</li>'; return; }
  ul.innerHTML = list.map((i) => `
    <li class="${i.severity}">
      <div class="t">${i.type}</div>
      <div class="m">${i.junction} &middot; ${i.severity.toUpperCase()} &middot; ${i.ageSec}s ago</div>
    </li>`).join("");
}

function renderTable(junctions) {
  const rows = [...junctions].sort((a, b) => b.congestion - a.congestion).map((j) => {
    const pct = Math.round(j.congestion * 100);
    return `<tr>
      <td><strong>${j.name}</strong></td>
      <td><span class="bar"><i style="width:${pct}%;background:${COLORS[j.level]}"></i></span>${pct}%</td>
      <td><span class="pill ${j.level}">${LEVEL_LABEL[j.level]}</span></td>
      <td>${j.avgSpeed} km/h</td>
      <td>${j.vehicles.toLocaleString("en-IN")}</td>
      <td><span class="sig ${j.signalPhase}"></span>${j.signalPhase} &middot; ${Math.max(j.signalTimer, 0)}s</td>
    </tr>`;
  });
  $("tbody").innerHTML = rows.join("");
}

/* ---------------- Data loop ---------------- */
let lastHistory = [], lastData = null;

function setStatus(ok, msg) {
  $("statusDot").className = "dot " + (ok ? "live" : "err");
  $("statusText").textContent = msg;
}

async function refresh() {
  try {
    // Relative URLs => works locally AND on Render (same origin)
    const [tRes, hRes] = await Promise.all([fetch("/api/traffic"), fetch("/api/history")]);
    if (!tRes.ok || !hRes.ok) throw new Error("bad response");
    lastData = await tRes.json();
    lastHistory = await hRes.json();

    renderKpis(lastData.kpis);
    drawMap(lastData);
    renderIncidents(lastData.incidents);
    renderTable(lastData.junctions);
    drawTrend(lastHistory);
    drawBars(lastData.junctions);
    setStatus(true, "Live");
  } catch (e) {
    console.error(e);
    setStatus(false, "Server unreachable - retrying…");
  }
}

window.addEventListener("resize", () => {
  if (lastData) { drawTrend(lastHistory); drawBars(lastData.junctions); }
});

refresh();
setInterval(refresh, REFRESH_MS);
